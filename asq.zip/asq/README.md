


librairies utilisées : 
-BeautifulSoup4 de la bibliotheque python
-requests




